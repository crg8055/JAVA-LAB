package CIE;
import java.util.*;
public class Internals{

    int marks[]=new int[5];

     Scanner s=new Scanner(System.in);
     public void getdata()
   { 
      System.out.println("Enter the marks of 5 Subjects:");
      for(int i=0;i<5;i++)
      marks[i]=s.nextInt();
   } 
   
  public void disp()
   {
     System.out.println("The CIE Marks of 5 Subjects are:");
     for(int i=0;i<5;i++)
     System.out.println(marks[i]);
   }
}

