package CIE;
import java.util.*;
public class Student{
 
   String usn;
   String name;
   int sem;
   
   Scanner sc=new Scanner(System.in);
   public void getdata()
   { 
      System.out.println("Enter the USN, Name & SEM");
      usn=sc.nextLine();
      name=sc.nextLine();
      sem=sc.nextInt();
   } 
   
   public void disp()
   {
     System.out.println("The Entered details are:");
     System.out.println("USN:"+usn);
     System.out.println("Name:"+name);
     System.out.println("Sem:"+sem);
   }
   
}



