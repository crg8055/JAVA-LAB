import CIE.*;
import SEE.*;
import java.util.*;
class Demo
{
	public static void main(String args[])
	{
		 Scanner sc=new Scanner(System.in);
		 
		System.out.println("Enter number of students: ");
		int n = sc.nextInt();
			Student s[] = new Student[n];
		 	Internals i[] = new Internals[n];
		 	External e[]=new External[n];
		
		
		for(int j =0;j<n;j++){
		
		s[j].getdata();
		
		
	
		i[j].getdata();
		
		
		
		e[j].get();
		
		}
		for(int k =0;k<n;k++){
		
		
		s[k].disp();
		
	
		
		i[k].disp();
		
		
		
		e[k].disp();
		}
		
		
		
	}

}
