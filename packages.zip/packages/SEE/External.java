package SEE;
import java.util.*;


public class External 
{
  int SEE_Marks[]=new int[5];
  Scanner ss=new Scanner(System.in);
  
  public void get()
  {
    System.out.println("Enter SEE Marks of 5 Subjects");
    for(int i=0;i<5;i++)
    SEE_Marks[i]=ss.nextInt();
  }
  
  public void disp()
  {
    System.out.println("The SEE Marks of 5 Subjects are:");
    for(int i=0;i<5;i++)
    System.out.println(SEE_Marks[i]);
  }
}


